﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Esta clase es la base de todos los personajes, tanto jugador como enemigos.

public abstract class BaseCharacter : MonoBehaviour
{
    public struct Stats
    {
        public float dmg;
        public float hp;
        public float speed;
        public float range;
    }

    protected Stats myStats;

    /*
    [SerializeField]
    protected string name = " "; No recuerdo bien por que puse esto pero me tira una advertencia así que lo comento.   */ 

    protected void ReceiveDmg(float damageReceived)
    {
        myStats.hp -= damageReceived;

        if (myStats.hp <= 0)
        {
            Die();
        }
    }

    protected abstract void Die();

    /*
        Los jugadores atacan, utilizan objetos e interactuan con NPCs. 
        Los NPCs otorgan misiones y hablan con los jugadores.
        Los enemigos atacan al jugador.
    */
    protected abstract void Action();
    protected abstract void Move();


}
