﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class EnemyCharacter : NPCCharacter
{
    protected static int enemyCount = 0;

    protected override void Action()
    {
        //Atacar
    }

    protected override void Move()
    {
        //moverse claramente
    }

    protected override void Die()
    {
        enemyCount--;
        Destroy(gameObject);
    }


}

public class TankEnemy : EnemyCharacter
{
    public TankEnemy()
    {
        /*
        stats.hp = 100;
        stats.dmg = 75;
        stats.speed = 2f;
        stats.range = 25f;

        Los comento porque después me fijo con más atención que poner en cada uno
        */

        enemyCount ++;
    }
}


public class FastEnemy : EnemyCharacter
{
    public FastEnemy()
    {
        /*
        stats.hp = 100;
        stats.dmg = 75;
        stats.speed = 2f;
        stats.range = 25f;

        Los comento porque después me fijo con más atención que poner en cada uno
        */

        enemyCount ++;
    }
}