﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FriendlyCharacter : NPCCharacter
{
    protected override void Action()
    {
        //Acá probablemente sea la manera de interactuar con el jugador
        //Quizás a través de diálogos y misiones
    }

    protected override void Move()
    {
        // Dudo mucho que haga que se muevan los NPCs,
        // pero si descubro como hacer que algunas instancias si lo hagan capaz queda
    }

    protected override void Die()
    {
        //Probablemente los NPCs no mueran pero vuelvan a tener 100% de vida.
    }


}
