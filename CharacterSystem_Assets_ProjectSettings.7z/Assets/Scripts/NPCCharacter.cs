﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class NPCCharacter : BaseCharacter
{

    //No se me ocurre como relacionar a los tipos de NPC.
    //Esto lo dejo medio placeholder porque capaz lo quito y hago que hereden directo de BaseCharacter

}
