﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PlayableCharacter : BaseCharacter
{
    // Cada clase va a tener su propia habilidad especial.
    protected virtual void SpecialAbility()
    {
        //Acá poner algún tipo de Cooldown para las habilidades
        //Es algo que comparten todas las clases
    }

    protected void UseObject()
    {
        
    }

    /* 
        Tanto interactuar como un npc como entrar se hacen con interact
        Quizás haya que cambiar el nombre
        Quizás no sirva una mierda esta idea
     */
    protected void Interact()
    {

    }

    protected override void Move()
    {
        //Todos los personajes se mueven igual, sólo cambia su speed.
        //¿Entonces esto va acá o no?
    }

    protected override void Action()
    {
        //Acá vendría la mecánica principal de atacar.
    }

    protected override void Die()
    {
        Destroy(gameObject);
    }
}
