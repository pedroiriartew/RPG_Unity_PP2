﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rogue : PlayableCharacter
{
    public Rogue()
    {
        myStats.hp = 100;
        myStats.dmg = 75;
        myStats.speed = 2f;
        myStats.range = 25f;
    }

    protected override void SpecialAbility()
    {
        //ni idea
    }
}
