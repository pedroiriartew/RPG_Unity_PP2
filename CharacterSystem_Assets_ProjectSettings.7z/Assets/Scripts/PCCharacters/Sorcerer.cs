﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sorcerer : PlayableCharacter
{
    public Sorcerer()
    {
        myStats.hp = 75;
        myStats.dmg = 100;
        myStats.speed = 1.5f;
        myStats.range = 15f;
    }

    protected override void SpecialAbility()
    {
        //ni idea
    }
}
