﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Warrior : PlayableCharacter
{

    public Warrior()
    {
        myStats.hp = 50f;
        myStats.dmg = 150f;
        myStats.speed = 1.2f;
        myStats.range = 10f;
    }
    protected override void SpecialAbility()
    {
        //ni idea
    }

}
